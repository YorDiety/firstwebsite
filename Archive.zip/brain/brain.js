const yesButton = document.getElementById('button1');
const noButton = document.getElementById('button2');

yesButton.addEventListener('click', () => {
    alert("Uyy hala seryoso ba?");
    document.body.style.backgroundColor = '#ffcccc'; 
});

noButton.addEventListener('mouseover', () => {
   
    const maxTop = window.innerHeight - noButton.offsetHeight; 
    const maxLeft = window.innerWidth - noButton.offsetWidth; 
    
    const randomTop = Math.random() * maxTop;
    const randomLeft = Math.random() * maxLeft;

    noButton.style.position = 'absolute';  
    noButton.style.top = `${randomTop}px`;  
    noButton.style.left = `${randomLeft}px`; 
});

noButton.addEventListener('click', () => {
    alert("nagtab ampotek, andaya :<");
});
